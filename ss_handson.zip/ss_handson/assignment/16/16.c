/*
Project: 16.c
Author: Ritika Singh
Description: Program to perform mandatory file locking.
             This program implements a write lock using fcntl().
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int fd;
    struct flock lock;

    // Open the file for reading and writing
    fd = open("data.txt", O_RDWR);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    // Set up the write lock
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = 0;
    lock.l_len = 0;
    lock.l_pid = getpid();

    printf("Trying to acquire write lock...\n");

    // Apply the lock
    if (fcntl(fd, F_SETLKW, &lock) == -1)
    {
        perror("Error applying write lock");
        close(fd);
        return 1;
    }

    printf("Write lock acquired successfully.\n");
    printf("File is locked. PID = %d\n", getpid());
    printf("Press Enter to release the lock...\n");

    getchar();

    // Remove the lock
    lock.l_type = F_UNLCK;

    if (fcntl(fd, F_SETLK, &lock) == -1)
    {
        perror("Error releasing lock");
        close(fd);
        return 1;
    }

    printf("Write lock released successfully.\n");

    close(fd);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/16$ touch data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/16$ echo "hwllo worla " > data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/16$ catdata.txt
catdata.txt: command not found
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/16$ gcc 16.c -o 16.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/16$ ./16.out
Trying to acquire write lock...
Write lock acquired successfully.
File is locked. PID = 5605
Press Enter to release the lock...

Write lock released successfully.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/16$
*/