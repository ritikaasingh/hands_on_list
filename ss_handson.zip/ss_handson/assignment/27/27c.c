/*
Project: 27c.c
Author: Ritika Singh
Description: Program to execute the command "ls -Rl"
             using the execle() system call and pass
             the environment explicitly.
*/

#include <stdio.h>
#include <unistd.h>

int main()
{
    char *env[] = {
        "PATH=/bin:/usr/bin",
        "HOME=/tmp",
        NULL
    };

    printf("Executing ls -Rl using execle()...\n");

    execle("/bin/ls", "ls", "-Rl", (char *)NULL, env);

    perror("execle failed");

    return 1;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$ ./27c.out
Executing ls -Rl using execle()...
.:
total 48
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:04 27.out
-rwxrwxrwx 1 ritika ritika   660 Sep 21 06:04 27a.c
-rwxrwxrwx 1 ritika ritika   681 Sep 21 06:05 27b.c
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:05 27b.out
-rwxrwxrwx 1 ritika ritika   489 Sep 21 06:07 27c.c
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:08 27c.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$
*/