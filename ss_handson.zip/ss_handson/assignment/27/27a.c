/*
Project: 27a.c
Author: Ritika Singh
Description: Program to execute the command "ls -Rl"
             using the execl() system call.
*/

#include <stdio.h>
#include <unistd.h>

int main()
{
    printf("Executing ls -Rl using execl()...\n");

    execl("/bin/ls", "ls", "-Rl", (char *)NULL);

    perror("execl failed");

    return 1;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$ gcc 27a.c -o 27.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$ ./27.out
Executing ls -Rl using execl()...
.:
total 16
-rwxrwxrwx 1 ritika ritika 16032 Sep 21 06:03 27.out
-rwxrwxrwx 1 ritika ritika   341 Sep 21 06:03 27a.c
*/