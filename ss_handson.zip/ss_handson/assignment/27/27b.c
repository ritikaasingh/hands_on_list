/*
Project: 27b.c
Author: Ritika Singh
Description: Program to execute the command "ls -Rl"
             using the execlp() system call.
*/

#include <stdio.h>
#include <unistd.h>

int main()
{
    printf("Executing ls -Rl using execlp()...\n");

    execlp("ls", "ls", "-Rl", (char *)NULL);

    perror("execlp failed");

    return 1;
}


/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$ ./27b.out
Executing ls -Rl using execlp()...
.:
total 32
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:04 27.out
-rwxrwxrwx 1 ritika ritika   660 Sep 21 06:04 27a.c
-rwxrwxrwx 1 ritika ritika   338 Sep 21 06:04 27b.c
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:05 27b.out
*/