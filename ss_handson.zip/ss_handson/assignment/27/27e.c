/*
Project: 27e.c
Author: Ritika Singh
Description: Program to execute the command "ls -Rl"
             using the execvp() system call.
*/

#include <stdio.h>
#include <unistd.h>

int main()
{
    char *args[] = {
        "ls",
        "-Rl",
        NULL
    };

    printf("Executing ls -Rl using execvp()...\n");

    execvp("ls", args);

    perror("execvp failed");

    return 1;
}


/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$ ./27e.out
Executing ls -Rl using execvp()...
.:
total 104
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:09 24.out
-rwxrwxrwx 1 ritika ritika  1062 Sep 21 06:10 24d.c
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:04 27.out
-rwxrwxrwx 1 ritika ritika   660 Sep 21 06:04 27a.c
-rwxrwxrwx 1 ritika ritika   681 Sep 21 06:05 27b.c
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:05 27b.out
-rwxrwxrwx 1 ritika ritika  1004 Sep 21 06:08 27c.c
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:08 27c.out
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:09 27d.out
-rwxrwxrwx 1 ritika ritika   389 Sep 21 06:10 27e.c
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:11 27e.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$
*/