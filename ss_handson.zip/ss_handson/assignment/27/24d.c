/*
Project: 27d.c
Author: Ritika Singh
Description: Program to execute the command "ls -Rl"
             using the execv() system call.
*/

#include <stdio.h>
#include <unistd.h>

int main()
{
    char *args[] = {
        "ls",
        "-Rl",
        NULL
    };

    printf("Executing ls -Rl using execv()...\n");

    execv("/bin/ls", args);

    perror("execv failed");

    return 1;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$ ./27d.out
Executing ls -Rl using execv()...
.:
total 84
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:09 24.out
-rwxrwxrwx 1 ritika ritika   389 Sep 21 06:09 24d.c
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:04 27.out
-rwxrwxrwx 1 ritika ritika   660 Sep 21 06:04 27a.c
-rwxrwxrwx 1 ritika ritika   681 Sep 21 06:05 27b.c
-rwxrwxrwx 1 ritika ritika 16040 Sep 21 06:05 27b.out
-rwxrwxrwx 1 ritika ritika  1004 Sep 21 06:08 27c.c
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:08 27c.out
-rwxrwxrwx 1 ritika ritika 16088 Sep 21 06:09 27d.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/27$
*/