
/*
Project: 21.c
Author: Ritika Singh
Description: Program to create a child process using fork()
             and print the parent and child process IDs.
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    pid_t pid;

    // Create a child process
    pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return 1;
    }
    else if (pid == 0)
    {
        // Child process
        printf("Child Process:\n");
        printf("Child PID   : %d\n", getpid());
        printf("Parent PID  : %d\n", getppid());
    }
    else
    {
        // Parent process
        printf("Parent Process:\n");
        printf("Parent PID  : %d\n", getpid());
        printf("Child PID   : %d\n", pid);
    }

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/21$ gcc 21.c -o 21.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/21$ ./21.out
Parent Process:
Child Process:
Parent PID  : 27009
Child PID   : 27010
Child PID   : 27010
Parent PID  : 27009
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/21$
*/
