/*
Project Name : 7.c
Author : Ritika Singh

Description:
Copy file1 into file2 using read() and write() system calls.
Equivalent to: cp file1 file2
*/

#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int main()
{
    int fd1, fd2;
    char buffer[1024];
    int n;

    // Open file1 for reading
    fd1 = open("file1", O_RDONLY);

    if (fd1 == -1)
    {
        perror("Error opening file1");
        return 1;
    }

    // Create file2 for writing
    fd2 = open("file2", O_WRONLY | O_CREAT | O_TRUNC, 0666);

    if (fd2 == -1)
    {
        perror("Error creating file2");
        close(fd1);
        return 1;
    }

    // Read from file1 and write to file2
    while ((n = read(fd1, buffer, sizeof(buffer))) > 0)
    {
        write(fd2, buffer, n);
    }

    // Close both files
    close(fd1);
    close(fd2);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$ echo "welcome to india mannn!!!" >file1
echo "welcome to india mannncode 7.c!" >file1
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$ cat file1
welcome to india mannncode 7.c!

ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$ gcc 7.c -o  7.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$ ls
7.c  7.out  file1

ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$ ./7.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$ ls
7.c  7.out  file1  file2
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$ cat file2
welcome to india mannncode 7.c!
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/7$


*/