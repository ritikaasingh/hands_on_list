
/*
Project: 19.c
Author: Ritika Singh
Description: Program to find the time taken to execute the
             getpid() system call using the Time Stamp Counter (TSC).
*/

#include <stdio.h>
#include <unistd.h>
#include <stdint.h>

/*
   Read the Time Stamp Counter using the RDTSC instruction.
*/
static inline uint64_t rdtsc()
{
    unsigned int low, high;

    __asm__ volatile(
        "rdtsc"
        : "=a"(low), "=d"(high)
    );

    return ((uint64_t)high << 32) | low;
}

int main()
{
    uint64_t start, end;
    pid_t pid;

    /*
       Read TSC before executing getpid()
    */
    start = rdtsc();

    /*
       Execute getpid() system call
    */
    pid = getpid();

    /*
       Read TSC after executing getpid()
    */
    end = rdtsc();

    printf("Process ID: %d\n", pid);
    printf("Time taken to execute getpid(): %lu CPU cycles\n",
           (unsigned long)(end - start));

    return 0;
}
/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/19$ gcc 19.c -o 19.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/19$ ./19.out
Process ID: 25303
Time taken to execute getpid(): 7458 CPU cycles
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/19$ ./19.out
Process ID: 25355
Time taken to execute getpid(): 6776 CPU cycles
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/19$ ./19.out
Process ID: 25377
Time taken to execute getpid(): 9088 CPU cycles
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/19$

*/