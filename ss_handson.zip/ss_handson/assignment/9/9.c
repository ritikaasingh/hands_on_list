/*
Project Name : 9.c
Author : Ritika Singh

Description:
Print information about a given file:
a. inode
b. number of hard links
c. uid
d. gid
e. size
f. block size
g. number of blocks
h. time of last access
i. time of last modification
j. file type
*/

#include <stdio.h>
#include <sys/stat.h>
#include <time.h>

int main()
{
    struct stat file;

    if (stat("file1", &file) == -1)
    {
        perror("stat");
        return 1;
    }

    printf("Inode number       : %ld\n", file.st_ino);
    printf("Number of links    : %ld\n", file.st_nlink);
    printf("UID                : %d\n", file.st_uid);
    printf("GID                : %d\n", file.st_gid);
    printf("File size          : %ld bytes\n", file.st_size);
    printf("Block size         : %ld bytes\n", file.st_blksize);
    printf("Number of blocks   : %ld\n", file.st_blocks);

    printf("Last access time   : %s", ctime(&file.st_atime));
    printf("Last modification  : %s", ctime(&file.st_mtime));

    if (S_ISREG(file.st_mode))
        printf("File type          : Regular file\n");
    else if (S_ISDIR(file.st_mode))
        printf("File type          : Directory\n");
    else if (S_ISLNK(file.st_mode))
        printf("File type          : Symbolic link\n");
    else
        printf("File type          : Other\n");

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/9$ gcc 9.c -o 9.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/9$ ls
9.c  9.out  file1
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/9$ ./9.out
Inode number       : 11258999068725623
Number of links    : 1
UID                : 1000
GID                : 1000
File size          : 23 bytes
Block size         : 4096 bytes
Number of blocks   : 0
Last access time   : Sun Sep 20 18:49:04 2026
Last modification  : Sun Sep 20 18:49:04 2026
File type          : Regular file
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/9$
*/