/*
Project: 26.c
Author: Ritika Singh
Description: Program to execute another executable program using
             execl(). The program also passes an argument to the
             executable program.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    printf("Executing hello.out...\n");

    execl("./hello.out", "./hello.out", "Ritika", (char *)NULL);

    /* This executes only if execl() fails */
    perror("execl failed");

    return 1;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/26$ gcc hello.c -o hello.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/26$ ./hello.out Ritika
Hello, Ritika!
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/26$ gcc 26.c -o 26.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/26$ ./26.out
Executing hello.out...
Hello, Ritika!
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/26$
*/