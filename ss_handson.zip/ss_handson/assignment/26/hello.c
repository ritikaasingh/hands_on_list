/*
Project: 26.c
Author: Ritika Singh
Description: Executable program that accepts a name as a
             command-line argument and prints a greeting.
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: %s <name>\n", argv[0]);
        return 1;
    }

    printf("Hello, %s!\n", argv[1]);

    return 0;
}