/*
Project Name : 5.c
Author : Ritika Singh

Description:
Write a program to create five new files with infinite loop.
Execute the program in the background and check the file
descriptor table at /proc/pid/fd.
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd1, fd2, fd3, fd4, fd5;

    fd1 = open("file1.txt", O_CREAT | O_RDWR, 0666);
    fd2 = open("file2.txt", O_CREAT | O_RDWR, 0666);
    fd3 = open("file3.txt", O_CREAT | O_RDWR, 0666);
    fd4 = open("file4.txt", O_CREAT | O_RDWR, 0666);
    fd5 = open("file5.txt", O_CREAT | O_RDWR, 0666);

    printf("Files opened successfully.\n");
    printf("PID = %d\n", getpid());

    while (1)
    {
        sleep(1);
    }

    return 0;
}


/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/5$ ls -l /proc/6416/fd
total 0
lrwx------ 1 ritika ritika 64 Sep 20 18:09 0 -> /dev/pts/4
lrwx------ 1 ritika ritika 64 Sep 20 18:09 1 -> /dev/pts/4
lrwx------ 1 ritika ritika 64 Sep 20 18:09 2 -> /dev/pts/4
lrwx------ 1 ritika ritika 64 Sep 20 18:09 3 -> /mnt/c/Users/ritik/Desktop/ss_handson/assignment/5/file1.txt
lrwx------ 1 ritika ritika 64 Sep 20 18:09 4 -> /mnt/c/Users/ritik/Desktop/ss_handson/assignment/5/file2.txt
lrwx------ 1 ritika ritika 64 Sep 20 18:09 5 -> /mnt/c/Users/ritik/Desktop/ss_handson/assignment/5/file3.txt
lrwx------ 1 ritika ritika 64 Sep 20 18:09 6 -> /mnt/c/Users/ritik/Desktop/ss_handson/assignment/5/file4.txt
lrwx------ 1 ritika ritika 64 Sep 20 18:09 7 -> /mnt/c/Users/ritik/Desktop/ss_handson/assignment/5/file5.txt

ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/5$ ls -l
total 16
-rwxrwxrwx 1 ritika ritika   727 Sep 20 18:08 5.c
-rwxrwxrwx 1 ritika ritika 16120 Sep 20 18:09 5.out
-rwxrwxrwx 1 ritika ritika     0 Sep 20 18:09 file1.txt
-rwxrwxrwx 1 ritika ritika     0 Sep 20 18:09 file2.txt
-rwxrwxrwx 1 ritika ritika     0 Sep 20 18:09 file3.txt
-rwxrwxrwx 1 ritika ritika     0 Sep 20 18:09 file4.txt
-rwxrwxrwx 1 ritika ritika     0 Sep 20 18:09 file5.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/5$ kill 6416
[1]+  Terminated                 ./5.out


*/

