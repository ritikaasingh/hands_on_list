/*
Project  Name : 3.c
Author : Ritika Singh
Proj Description : Write a program to create a file and print the file 
                   descriptor value. Use creat ( ) system call
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;

    fd = creat("myfile.txt", 0644);

    if (fd == -1)
    {
        perror("Error creating file");
        return 1;
    }

    printf("File created successfully.\n");
    printf("File descriptor: %d\n", fd);

    close(fd);

    return 0;
}

/*
ritika@Ritesh:~$ cd /mnt/c/Users/ritik/Desktop/ss_handson/assignment/3
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/3$ gcc 3.c
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/3$ rrirrrrrrrrrrrrrrirrrrriritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/3$ ./a.out
File created successfully.
File descriptor: 3
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/3$ ls
3.c  a.out  myfile.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/3$ ls -l
total 16
-rwxrwxrwx 1 ritika ritika   511 Sep 20 14:41 3.c
-rwxrwxrwx 1 ritika ritika 16120 Sep 20 15:01 a.out
-rwxrwxrwx 1 ritika ritika     0 Sep 20 15:03 myfile.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/3$

*/