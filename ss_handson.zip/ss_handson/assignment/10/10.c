/*
Project Name : 10.c
Author : Ritika Singh

Description:
Open a file in read-write mode, write 10 bytes,
move the file pointer by 10 bytes using lseek(),
and write another 10 bytes.
Check the return value of lseek().
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;
    off_t position;

    // Open file in read-write mode
    fd = open("data.txt", O_RDWR | O_CREAT | O_TRUNC, 0666);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    // Write first 10 bytes
    write(fd, "ABCDEFGHIJ", 10);

    // Move file pointer 10 bytes forward
    position = lseek(fd, 10, SEEK_CUR);

    // Check return value of lseek
    if (position == -1)
    {
        perror("lseek failed");
        close(fd);
        return 1;
    }

    printf("Return value of lseek = %ld\n", position);

    // Write another 10 bytes
    write(fd, "1234567890", 10);

    close(fd);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/10$ gcc 10.c -o 10.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/10$ ./10.out
Return value of lseek = 20
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/10$ ls -l data.txt
-rwxrwxrwx 1 ritika ritika 30 Sep 20 18:56 data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/10$ od -c data.txt
0000000   A   B   C   D   E   F   G   H   I   J  \0  \0  \0  \0  \0  \0
0000020  \0  \0  \0  \0   1   2   3   4   5   6   7   8   9   0
0000036

ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/10$ od -An -t x1 data.txt
 41 42 43 44 45 46 47 48 49 4a 00 00 00 00 00 00
 00 00 00 00 31 32 33 34 35 36 37 38 39 30

*/