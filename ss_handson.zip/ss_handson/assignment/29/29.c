/*
Project: 29.c
Author: Ritika Singh
Description: Program to get the current scheduling policy and
             modify it to SCHED_FIFO and SCHED_RR.
*/

#include <stdio.h>
#include <unistd.h>
#include <sched.h>
#include <errno.h>
#include <string.h>

void print_policy(int policy)
{
    if (policy == SCHED_OTHER)
        printf("Scheduling Policy: SCHED_OTHER\n");
    else if (policy == SCHED_FIFO)
        printf("Scheduling Policy: SCHED_FIFO\n");
    else if (policy == SCHED_RR)
        printf("Scheduling Policy: SCHED_RR\n");
    else
        printf("Scheduling Policy: Unknown\n");
}

int main()
{
    int policy;
    struct sched_param param;

    /* Get current scheduling policy */
    policy = sched_getscheduler(0);

    if (policy == -1)
    {
        perror("sched_getscheduler");
        return 1;
    }

    printf("Current scheduling policy:\n");
    print_policy(policy);

    /*
     * Get the minimum priority for SCHED_FIFO.
     * We use this priority when trying to change the policy.
     */
    param.sched_priority = sched_get_priority_min(SCHED_FIFO);

    /* Change scheduling policy to SCHED_FIFO */
    printf("\nTrying to change policy to SCHED_FIFO...\n");

    if (sched_setscheduler(0, SCHED_FIFO, &param) == -1)
    {
        printf("Cannot change to SCHED_FIFO: %s\n",
               strerror(errno));
    }
    else
    {
        printf("Policy changed to SCHED_FIFO successfully.\n");
    }

    /* Check current policy again */
    policy = sched_getscheduler(0);

    if (policy != -1)
        print_policy(policy);

    /*
     * Get the minimum priority for SCHED_RR.
     */
    param.sched_priority = sched_get_priority_min(SCHED_RR);

    /* Change scheduling policy to SCHED_RR */
    printf("\nTrying to change policy to SCHED_RR...\n");

    if (sched_setscheduler(0, SCHED_RR, &param) == -1)
    {
        printf("Cannot change to SCHED_RR: %s\n",
               strerror(errno));
    }
    else
    {
        printf("Policy changed to SCHED_RR successfully.\n");
    }

    /* Check current policy again */
    policy = sched_getscheduler(0);

    if (policy != -1)
        print_policy(policy);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/29$ gcc 29.c -o 29.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/29$ ./29.out
Current scheduling policy:
Scheduling Policy: SCHED_OTHER

Trying to change policy to SCHED_FIFO...
Cannot change to SCHED_FIFO: Operation not permitted
Scheduling Policy: SCHED_OTHER

Trying to change policy to SCHED_RR...
Cannot change to SCHED_RR: Operation not permitted
Scheduling Policy: SCHED_OTHER

*/