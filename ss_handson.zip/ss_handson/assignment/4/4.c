/*
Project  Name : 4.c
Author : Ritika Singh
Proj Description : Write a program to open an existing file with read write mode.
                   Try O_EXCL flag also. 

*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;

    // Open existing file in read-write mode
    fd = open("hello.txt", O_RDWR | O_EXCL);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    printf("File opened successfully.\n");
    printf("File descriptor: %d\n", fd);

    close(fd);

    return 0;
}