
/*
Project: 14.c
Author: Ritika Singh
Description: Program to identify the type of a file.
             The file path is taken from the command line.
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    struct stat file_info;

    // Check whether filename is provided
    if (argc != 2)
    {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    // Get information about the file
    if (lstat(argv[1], &file_info) == -1)
    {
        perror("lstat");
        return 1;
    }

    // Identify the type of file
    if (S_ISREG(file_info.st_mode))
    {
        printf("%s is a Regular File.\n", argv[1]);
    }
    else if (S_ISDIR(file_info.st_mode))
    {
        printf("%s is a Directory.\n", argv[1]);
    }
    else if (S_ISLNK(file_info.st_mode))
    {
        printf("%s is a Symbolic Link.\n", argv[1]);
    }
    else if (S_ISFIFO(file_info.st_mode))
    {
        printf("%s is a FIFO (Named Pipe).\n", argv[1]);
    }
    else if (S_ISSOCK(file_info.st_mode))
    {
        printf("%s is a Socket.\n", argv[1]);
    }
    else if (S_ISCHR(file_info.st_mode))
    {
        printf("%s is a Character Device.\n", argv[1]);
    }
    else if (S_ISBLK(file_info.st_mode))
    {
        printf("%s is a Block Device.\n", argv[1]);
    }
    else
    {
        printf("%s is an Unknown File Type.\n", argv[1]);
    }

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ gcc 14.c -o 14.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ ./14.out
Usage: ./14.out <filename>
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ touch data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ ./14.out data.txt
data.txt is a Regular File.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ mkdir testdir
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ ./14.out testdir
testdir is a Directory.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ ln -s data.txt softlink
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ ./14 softlink
-bash: ./14: No such file or directory
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$ ./14.out softlink
softlink is a Symbolic Link.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/14$
*/