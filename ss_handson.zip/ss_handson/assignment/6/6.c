/*
Project Name : 6.c
Author : Ritika Singh

Description:
Take input from STDIN and display it on STDOUT
using only read() and write() system calls.
*/

#include <unistd.h>

int main()
{
    char buffer[100];

    int n = read(STDIN_FILENO, buffer, sizeof(buffer));

    if (n > 0)
    {
        write(STDOUT_FILENO, buffer, n);
    }

    return 0;
}

/*
itika@Ritesh:~$ cd /mnt/c/Users/ritik/Desktop/ss_handson/assignment/6
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/6$ touch 6.c
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/6$ code 6.c
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/6$ gcc 6.c -o 6.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/6$ ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignmeritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/6$ ./6.out
Hello Ritika
Hello Ritika
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/6$

*/