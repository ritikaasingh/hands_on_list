/*
Project: 23.c
Author: Ritika Singh
Description: Program to create a zombie process.
             The child process terminates while the parent process
             remains running without calling wait().
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    pid_t pid;

    pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return 1;
    }
    else if (pid == 0)
    {
        /* Child process */
        printf("Child process is running.\n");
        printf("Child PID: %d\n", getpid());
        printf("Child process is terminating...\n");

        exit(0);
    }
    else
    {
        /* Parent process */
        printf("Parent process is running.\n");
        printf("Parent PID: %d\n", getpid());
        printf("Child PID: %d\n", pid);

        printf("Parent is sleeping for 30 seconds.\n");
        printf("During this time, the child becomes a ZOMBIE.\n");

        sleep(30);

        printf("Parent process is terminating.\n");
    }

    return 0;
}


/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/23$ ./23.out
Parent process is running.
Child process is running.
Parent PID: 29264
Child PID: 29265
Child PID: 29265
Child process is terminating...
Parent is sleeping for 30 seconds.
During this time, the child becomes a ZOMBIE.
Parent process is terminating.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/23$


ritika@Ritesh:~$ ps -el | grep 29265
1 Z  1000   29265   29264  0  80   0 -     0 -      pts/0    00:00:00 23.out
*/