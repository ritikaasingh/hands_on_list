/*
Project Name : 8.c
Author : Ritika Singh

Description:
Open a file in read-only mode, read it line by line,
display each line as it is read, and close the file
when end of file is reached.
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;
    char ch;

    // Open file in read-only mode
    fd = open("input.txt", O_RDONLY);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    // Read one character at a time
    while (read(fd, &ch, 1) > 0)
    {
        // Display the character
        write(STDOUT_FILENO, &ch, 1);
    }

    // Close the file at end of file
    close(fd);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/8$ touch input.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/8$ code input.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/8$ ls
8.c  8.out  input.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/8$ ./8.out
Hello World
This is Ritika
I love laughing , enjoying my life
You should do it too!!!ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/8$
*/