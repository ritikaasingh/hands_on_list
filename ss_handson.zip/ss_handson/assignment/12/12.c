/*
Project: 12.c
Author: Ritika Singh
Description: Program to find out the opening mode of a file using fcntl().
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;
    int flags;

    // Open the file in read-write mode
    fd = open("data.txt", O_RDWR);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    // Get the file status flags using fcntl()
    flags = fcntl(fd, F_GETFL);

    if (flags == -1)
    {
        perror("fcntl error");
        close(fd);
        return 1;
    }

    // Check the opening mode
    switch (flags & O_ACCMODE)
    {
        case O_RDONLY:
            printf("File is opened in READ ONLY mode.\n");
            break;

        case O_WRONLY:
            printf("File is opened in WRITE ONLY mode.\n");
            break;

        case O_RDWR:
            printf("File is opened in READ and WRITE mode.\n");
            break;

        default:
            printf("Unknown opening mode.\n");
    }

    close(fd);

    return 0;
}

/*
ritika@Ritesh:~$ cd /mnt/c/Users/ritik/Desktop/ss_handson/assignment/12
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignmentritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$ touch data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$ echo "hello world" > data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$ cat data.txt
hello world
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$ gcc 12.c -o 12
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$ ls
12  12.c  12.out  data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$ ./12
File is opened in READ and WRITE mode.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$ ls  -l
total 36
-rwxrwxrwx 1 ritika ritika 16120 Sep 21 03:17 12
-rwxrwxrwx 1 ritika ritika  1041 Sep 21 03:17 12.c
-rwxrwxrwx 1 ritika ritika 16120 Sep 20 19:20 12.out
-rwxrwxrwx 1 ritika ritika    12 Sep 21 03:16 data.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/12$

*/