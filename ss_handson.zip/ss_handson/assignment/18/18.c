/*
Project: 18.c
Author: Ritika Singh
Description: Program to perform record locking using fcntl().
             Three records are stored in a file.
             The program implements both read lock and write lock
             on a particular record to avoid race conditions.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

struct record
{
    int id;
    char name[30];
    int age;
};

/*
   Lock a particular record.

   record_number = record to lock (1, 2 or 3)
   lock_type = F_RDLCK for read lock
               F_WRLCK for write lock
*/
void lock_record(int fd, int record_number, short lock_type)
{
    struct flock lock;

    lock.l_type = lock_type;
    lock.l_whence = SEEK_SET;
    lock.l_start = (record_number - 1) * sizeof(struct record);
    lock.l_len = sizeof(struct record);
    lock.l_pid = getpid();

    printf("Trying to acquire %s lock on record %d...\n",
           lock_type == F_RDLCK ? "READ" : "WRITE",
           record_number);

    if (fcntl(fd, F_SETLKW, &lock) == -1)
    {
        perror("fcntl");
        exit(1);
    }

    printf("%s lock acquired on record %d.\n",
           lock_type == F_RDLCK ? "READ" : "WRITE",
           record_number);
}

/*
   Unlock a particular record.
*/
void unlock_record(int fd, int record_number)
{
    struct flock lock;

    lock.l_type = F_UNLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = (record_number - 1) * sizeof(struct record);
    lock.l_len = sizeof(struct record);
    lock.l_pid = getpid();

    if (fcntl(fd, F_SETLK, &lock) == -1)
    {
        perror("fcntl");
        exit(1);
    }

    printf("Record %d unlocked.\n", record_number);
}

int main()
{
    int fd;
    int choice;
    int record_number;
    struct record r;

    /*
       Open the file.
       O_CREAT creates it if it does not exist.
       O_RDWR allows reading and writing.
    */
    fd = open("records.dat", O_RDWR | O_CREAT, 0666);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    /*
       Check whether the file is empty.
       If empty, create three records.
    */
    if (lseek(fd, 0, SEEK_END) == 0)
    {
        struct record records[3] =
        {
            {1, "Ritika", 24},
            {2, "Rahul", 25},
            {3, "Ananya", 23}
        };

        if (write(fd, records, sizeof(records)) == -1)
        {
            perror("Error creating records");
            close(fd);
            return 1;
        }

        printf("Three records created successfully.\n");
    }

    printf("\n===== RECORD LOCKING =====\n");
    printf("1. Read a record (Read Lock)\n");
    printf("2. Modify a record (Write Lock)\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    printf("Enter record number (1-3): ");
    scanf("%d", &record_number);

    if (record_number < 1 || record_number > 3)
    {
        printf("Invalid record number.\n");
        close(fd);
        return 1;
    }

    /*
       READ LOCK
    */
    if (choice == 1)
    {
        lock_record(fd, record_number, F_RDLCK);

        // Move to the selected record
        lseek(fd,
              (record_number - 1) * sizeof(struct record),
              SEEK_SET);

        // Read the record
        if (read(fd, &r, sizeof(struct record)) == -1)
        {
            perror("Error reading record");
            unlock_record(fd, record_number);
            close(fd);
            return 1;
        }

        printf("\nRecord details:\n");
        printf("ID   : %d\n", r.id);
        printf("Name : %s\n", r.name);
        printf("Age  : %d\n", r.age);

        unlock_record(fd, record_number);
    }

    /*
       WRITE LOCK
    */
    else if (choice == 2)
    {
        lock_record(fd, record_number, F_WRLCK);

        // Move to the selected record
        lseek(fd,
              (record_number - 1) * sizeof(struct record),
              SEEK_SET);

        // Read the existing record
        if (read(fd, &r, sizeof(struct record)) == -1)
        {
            perror("Error reading record");
            unlock_record(fd, record_number);
            close(fd);
            return 1;
        }

        printf("\nCurrent record:\n");
        printf("ID   : %d\n", r.id);
        printf("Name : %s\n", r.name);
        printf("Age  : %d\n", r.age);

        // Take new name and age
        printf("\nEnter new name: ");
        scanf("%29s", r.name);

        printf("Enter new age: ");
        scanf("%d", &r.age);

        // Move back to the beginning of the record
        lseek(fd,
              (record_number - 1) * sizeof(struct record),
              SEEK_SET);

        // Write modified record
        if (write(fd, &r, sizeof(struct record)) == -1)
        {
            perror("Error writing record");
            unlock_record(fd, record_number);
            close(fd);
            return 1;
        }

        printf("\nRecord %d modified successfully.\n", record_number);

        unlock_record(fd, record_number);
    }

    else
    {
        printf("Invalid choice.\n");
    }

    close(fd);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/18$ gcc 18.c -o 18.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/18$ ./18.out
Three records created successfully.

===== RECORD LOCKING =====
1. Read a record (Read Lock)
2. Modify a record (Write Lock)
Enter your choice: 1
Enter record number (1-3): 2
Trying to acquire READ lock on record 2...
READ lock acquired on record 2.

Record details:
ID   : 2
Name : Rahul
Age  : 25
Record 2 unlocked.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/18$ ./18.out

===== RECORD LOCKING =====
1. Read a record (Read Lock)
2. Modify a record (Write Lock)
Enter your choice: 2
Enter record number (1-3): 2
Trying to acquire WRITE lock on record 2...
WRITE lock acquired on record 2.

Current record:
ID   : 2
Name : Rahul
Age  : 25

Enter new name: happy
Enter new age: 32

Record 2 modified successfully.
Record 2 unlocked.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/18$ ./18.out

===== RECORD LOCKING =====
1. Read a record (Read Lock)
2. Modify a record (Write Lock)
Enter your choice: 1
Enter record number (1-3): 2
Trying to acquire READ lock on record 2...
READ lock acquired on record 2.

Record details:
ID   : 2
Name : happy
Age  : 32
Record 2 unlocked.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/18$
*/