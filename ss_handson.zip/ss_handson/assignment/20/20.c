
/*
Project: 20.c
Author: Ritika Singh
Description: Program to find out the priority of the running program.
             The priority is obtained using getpriority().
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/resource.h>

int main()
{
    int priority;

    // Get the priority of the current process
    priority = getpriority(PRIO_PROCESS, 0);

    printf("Process ID: %d\n", getpid());
    printf("Current priority (nice value): %d\n", priority);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$ gcc 20.c -o 20.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$ ./20.out
Process ID: 25889
Current priority (nice value): 0
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$ nice -n 5 ./20
nice: ./20: No such file or directory (os error 2)
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$ nice -n 5 ./20.out
Process ID: 26017
Current priority (nice value): 5
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$ nice -n 10 ./20.out
Process ID: 26063
Current priority (nice value): 10
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$ ps -o pid,ni,pri,cmd
    PID  NI PRI CMD
    329   0  19 -bash
  26178   0  19 ps -o pid,ni,pri,cmd
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$ ps -o pid,ni,pri,cmd -p 26178
    PID  NI PRI CMD
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/20$
*/
