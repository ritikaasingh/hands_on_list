/*
Project: 24.c
Author: Ritika Singh
Description: Program to create an orphan process.
             The parent process terminates before the child process,
             causing the child to become an orphan process.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    pid_t pid;

    pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return 1;
    }
    else if (pid == 0)
    {
        /* Child process */
        printf("Child process started.\n");
        printf("Child PID  : %d\n", getpid());
        printf("Parent PID : %d\n", getppid());

        printf("\nChild is sleeping for 20 seconds...\n");
        sleep(20);

        printf("\nAfter parent terminates:\n");
        printf("Child PID  : %d\n", getpid());
        printf("New Parent PID : %d\n", getppid());

        printf("Child process is terminating.\n");
    }
    else
    {
        /* Parent process */
        printf("Parent process started.\n");
        printf("Parent PID : %d\n", getpid());
        printf("Child PID  : %d\n", pid);

        printf("\nParent process is terminating now...\n");

        exit(0);
    }

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/24$ gcc 24.c -o 24.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/24$ ./24.out
Parent process started.
Parent PID : 29920
Child PID  : 29921

Parent process is terminating now...
Child process started.
Child PID  : 29921
Parent PID : 29920

Child is sleeping for 20 seconds...
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/24$
After parent terminates:
Child PID  : 29921
New Parent PID : 328
Child process is terminating.

*/