/*
Project  Name : 2.c
Author : Ritika Singh
Proj Description : Write a simple program to execute in an infinite loop at the background. Go to /proc directory and
                   identify all the process related information in the corresponding proc directory. 
*/

#include <stdio.h>
#include <unistd.h>

int main() {
    while(1) {
        printf("Running process with PID: %d\n", getpid());
        sleep(8);   // sleep to avoid flooding the terminal
    }
    return 0;
}

/*
ritika@Ritesh:/$  cd /mnt/c/Users/ritik/Desktop/ss_handson/assignment/2
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/2$ gcc 2.c -o 2
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/2$ ls
2  2.c
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/2$ ./2
Running process with PID: 97257
Running process with PID: 97257
ritika@Ritesh:/$ kill 97257

Terminated                 ./2
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/2$ kkill pid
Command 'kkill' not found, did you mean:
  command 'xkill' from deb x11-utils (7.7+7build1)
  command 'skill' from deb procps (2:4.0.4-9ubuntu1)
  command 'tkill' from deb lam-runtime (7.1.4-8build1)
  command 'kill' from deb procps (2:4.0.4-9ubuntu1)
  command 'rkill' from deb pslist (1.4.0-6build1)
  command 'pkill' from deb procps (2:4.0.4-9ubuntu1)
Try: sudo apt install <deb name>
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/2$ kill 97running kill 97257
-bash: kill: `97running': not a pid or valid job spec
-bash: kill: `kill': not a pid or valid job spec
-bash: kill: (97257) - No such process
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/2$
*/