/*
Project: 25.c
Author: Ritika Singh
Description: Program to create three child processes.
             The parent process waits for a particular child
             using the waitpid() system call.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    pid_t child1, child2, child3;
    int status;

    /* Create first child */
    child1 = fork();

    if (child1 < 0)
    {
        perror("fork failed");
        return 1;
    }
    else if (child1 == 0)
    {
        printf("Child 1: PID = %d, Parent PID = %d\n",
               getpid(), getppid());

        sleep(2);

        printf("Child 1 is terminating.\n");
        exit(10);
    }

    /* Create second child */
    child2 = fork();

    if (child2 < 0)
    {
        perror("fork failed");
        return 1;
    }
    else if (child2 == 0)
    {
        printf("Child 2: PID = %d, Parent PID = %d\n",
               getpid(), getppid());

        sleep(4);

        printf("Child 2 is terminating.\n");
        exit(20);
    }

    /* Create third child */
    child3 = fork();

    if (child3 < 0)
    {
        perror("fork failed");
        return 1;
    }
    else if (child3 == 0)
    {
        printf("Child 3: PID = %d, Parent PID = %d\n",
               getpid(), getppid());

        sleep(3);

        printf("Child 3 is terminating.\n");
        exit(30);
    }

    /* Parent process */
    printf("\nParent PID = %d\n", getpid());
    printf("Child 1 PID = %d\n", child1);
    printf("Child 2 PID = %d\n", child2);
    printf("Child 3 PID = %d\n", child3);

    printf("\nParent is waiting specifically for Child 2...\n");

    if (waitpid(child2, &status, 0) == -1)
    {
        perror("waitpid failed");
        return 1;
    }

    printf("Parent has finished waiting for Child 2.\n");

    if (WIFEXITED(status))
    {
        printf("Child 2 exited with status: %d\n",
               WEXITSTATUS(status));
    }

    printf("Parent process is terminating.\n");

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/25$ gcc 25.c -o 25.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/25$ ./25.out
Child 1: PID = 31780, Parent PID = 31779

Parent PID = 31779
Child 1 PID = 31780
Child 2 PID = 31781
Child 3 PID = 31782

Parent is waiting specifically for Child 2...
Child 3: PID = 31782, Parent PID = 31779
Child 2: PID = 31781, Parent PID = 31779
Child 1 is terminating.
Child 3 is terminating.
Child 2 is terminating.
Parent has finished waiting for Child 2.
Child 2 exited with status: 20
Parent process is terminating.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/25$
*/