/*
Project: 28.c
Author: Ritika Singh
Description: Program to find the maximum and minimum real-time
             priority using sched_get_priority_max() and
             sched_get_priority_min().
*/

#include <stdio.h>
#include <sched.h>

int main()
{
    int max_priority;
    int min_priority;

    max_priority = sched_get_priority_max(SCHED_FIFO);
    min_priority = sched_get_priority_min(SCHED_FIFO);

    if (max_priority == -1 || min_priority == -1)
    {
        perror("Error getting real-time priority");
        return 1;
    }

    printf("Scheduling Policy: SCHED_FIFO\n");
    printf("Maximum real-time priority: %d\n", max_priority);
    printf("Minimum real-time priority: %d\n", min_priority);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment$ gcc 28.c -o 28.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment$ ./28.out
Scheduling Policy: SCHED_FIFO
Maximum real-time priority: 99
Minimum real-time priority: 1
*/