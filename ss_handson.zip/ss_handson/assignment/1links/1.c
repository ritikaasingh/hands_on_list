/*
Project  Name : 1.c
Author : Ritika Singh
Proj Description : Create the following types of a files using (i) shell command (ii) system call
                   a. soft link (symlink system call)
                   b. hard link (link system call)
                   c. FIFO (mkfifo Library Function or mknod system call)
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>

int main()
{
    // Create soft link
    if (symlink("original.txt", "softlink_c.txt") == -1)
    {
        perror("Error creating soft link");
    }
    else
    {
        printf("Soft link created successfully.\n");
    }

    // Create hard link
    if (link("original.txt", "hardlink_c.txt") == -1)
    {
        perror("Error creating hard link");
    }
    else
    {
        printf("Hard link created successfully.\n");
    }

    // Create FIFO
    if (mkfifo("myfifo_c", 0666) == -1)
    {
        perror("Error creating FIFO");
    }
    else
    {
        printf("FIFO created successfully.\n");
    }

    return 0;
}

/*
Output : 
Soft link created successfully.
Error creating hard link: No such file or directory
FIFO created successfully.

Equivalent Shell Command :
ritika@Ritesh:~$ mkdir -p ~//ss_handson/assignment
ritika@Ritesh:~$ cd ~//ss_handson/assignment
ritika@Ritesh:~/ss_handson/assignment$ echo "Hello from original file" > original.txt
ritika@Ritesh:~/ss_handson/assignment$ ls
original.txt
ritika@Ritesh:~/ss_handson/assignment$ ln -s original.txt softlink.txt
ritika@Ritesh:~/ss_handson/assignment$ ln  original.txt hardlink.txt
ritika@Ritesh:~/ss_handson/assignment$ mkfifo myfifo
ritika@Ritesh:~/ss_handson/assignment$ ls -l
total 8
-rw-r--r-- 2 ritika ritika 25 Sep 20 11:08 hardlink.txt
prw-r--r-- 1 ritika ritika  0 Sep 20 11:10 myfifo
-rw-r--r-- 2 ritika ritika 25 Sep 20 11:08 original.txt
lrwxrwxrwx 1 ritika ritika 12 Sep 20 11:08 softlink.txt -> original.txt

*/