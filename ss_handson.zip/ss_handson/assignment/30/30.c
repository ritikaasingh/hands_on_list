/*
Project: 30.c
Author: Ritika Singh
Description: Program to create a daemon process and execute
             a shell script at a specified time.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main()
{
    pid_t pid;
    int target_hour;
    int target_minute;

    printf("Enter time to run the script (HH MM): ");
    scanf("%d %d", &target_hour, &target_minute);

    /* Create child process */
    pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return 1;
    }

    /* Parent terminates */
    if (pid > 0)
    {
        printf("Daemon process created with PID: %d\n", pid);
        printf("Parent process terminating.\n");
        return 0;
    }

    /* Create new session */
    if (setsid() == -1)
    {
        perror("setsid failed");
        exit(1);
    }

    /* Change working directory */
    if (chdir("/") == -1)
    {
        perror("chdir failed");
        exit(1);
    }

    /* Close standard file descriptors */
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    while (1)
    {
        time_t current_time;
        struct tm *current;

        current_time = time(NULL);
        current = localtime(&current_time);

        if (current->tm_hour == target_hour &&
            current->tm_min == target_minute)
        {
            /*
             * Execute the shell script.
             * Use the absolute path because the daemon
             * changes its working directory to "/".
             */
            system("/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30/myscript.sh");

            break;
        }

        sleep(20);
    }

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ echo "Script executed successfully at $(21.09.2026)" >> script_output.txt
21.09.2026: command not found
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ echo "Script executed successfully at $(date)" >> script_output.txt
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ touch myscript.sh
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ code myscript.sh
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ chmod +x myscript.sh
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ ./myscript.sh
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ cat script_output.txt
Script executed successfully at
Script executed successfully at Mon Sep 21 06:23:39 UTC 2026
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ gcc 30.c -o 30.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ ./30.out
Enter time to run the script (HH MM): 11:59
Daemon process created with PID: 39085
Parent process terminating.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ ps -p 39085 -f
UID          PID    PPID  C STIME TTY          TIME CMD
ritika     39085     328  0 06:29 ?        00:00:00 ./30.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$ cat script_output.txt
Script executed successfully at
Script executed successfully at Mon Sep 21 06:23:39 UTC 2026
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/30$
*/