/*
Project: 17a.c
Author: Ritika Singh
Description: Program to open a file, store an initial ticket number,
             and exit.
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;
    int ticket_number = 100;

    // Open the file for writing
    fd = open("ticket.txt", O_WRONLY | O_CREAT | O_TRUNC, 0666);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    // Store the initial ticket number
    if (write(fd, &ticket_number, sizeof(ticket_number)) == -1)
    {
        perror("Error writing ticket number");
        close(fd);
        return 1;
    }

    printf("Initial ticket number %d stored successfully.\n", ticket_number);

    close(fd);

    return 0;
}
/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/17$ gcc 17a.c -o 17a.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/17$ ./17a.out
Initial ticket number 100 stored successfully.
*/