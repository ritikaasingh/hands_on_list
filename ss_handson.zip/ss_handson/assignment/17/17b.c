/*
Project: 17b.c
Author: Ritika Singh
Description: Program to simulate online ticket reservation.
             The program opens the ticket file, applies a write lock,
             reads the current ticket number, increments it, prints
             the new ticket number, and then closes the file.
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;
    int ticket_number;
    struct flock lock;

    // Open the ticket file for reading and writing
    fd = open("ticket.txt", O_RDWR);

    if (fd == -1)
    {
        perror("Error opening ticket file");
        return 1;
    }

    // Set up the write lock
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = 0;
    lock.l_len = 0;
    lock.l_pid = getpid();

    printf("Trying to acquire write lock...\n");

    // Apply the write lock
    if (fcntl(fd, F_SETLKW, &lock) == -1)
    {
        perror("Error applying write lock");
        close(fd);
        return 1;
    }

    printf("Write lock acquired successfully.\n");

    // Move to the beginning of the file
    lseek(fd, 0, SEEK_SET);

    // Read the current ticket number
    if (read(fd, &ticket_number, sizeof(ticket_number)) == -1)
    {
        perror("Error reading ticket number");
        close(fd);
        return 1;
    }

    // Increment the ticket number
    ticket_number++;

    // Move back to the beginning of the file
    lseek(fd, 0, SEEK_SET);

    // Store the new ticket number
    if (write(fd, &ticket_number, sizeof(ticket_number)) == -1)
    {
        perror("Error writing ticket number");
        close(fd);
        return 1;
    }

    printf("New ticket number: %d\n", ticket_number);

    // Release the write lock
    lock.l_type = F_UNLCK;

    if (fcntl(fd, F_SETLK, &lock) == -1)
    {
        perror("Error releasing write lock");
        close(fd);
        return 1;
    }

    printf("Write lock released successfully.\n");

    close(fd);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/17$ ./17b.out
Trying to acquire write lock...
Write lock acquired successfully.
New ticket number: 101
Write lock released successfully.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/17$ ./17b.out
Trying to acquire write lock...
Write lock acquired successfully.
New ticket number: 102
Write lock released successfully.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/17$
*/
