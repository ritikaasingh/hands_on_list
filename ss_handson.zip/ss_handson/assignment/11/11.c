/*
Project Name : 11_dup2.c
Author       : Ritika Singh
Description  : Duplicate a file descriptor using dup2()
               and append data using both descriptors.
*/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd, fd2;

    // Open file in append mode
    fd = open("data.txt", O_WRONLY | O_CREAT | O_APPEND, 0666);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    // Duplicate fd to descriptor 10
    fd2 = dup2(fd, 10);

    if (fd2 == -1)
    {
        perror("Error duplicating file descriptor");
        close(fd);
        return 1;
    }

    printf("Original file descriptor = %d\n", fd);
    printf("Duplicated file descriptor = %d\n", fd2);

    // Write using original descriptor
    write(fd, "Data written using fd\n", 22);

    // Write using duplicated descriptor
    write(fd2, "Data written using fd2\n", 23);

    close(fd);
    close(fd2);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/11$ ls
11.c  11.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/11$ ./11.out
Original file descriptor = 3
Duplicated file descriptor = 4
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/11$ cat data.txt
Data written using fd
Data written using fd2
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/11$ gcc 11.c -o 11.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/11$ ./11.out
Original file descriptor = 3
Duplicated file descriptor = 10
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/11$ cat data.txt
Data written using fd
Data written using fd2
Data written using fd

*/