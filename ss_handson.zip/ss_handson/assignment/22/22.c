/*
Project: 22.c
Author: Ritika Singh
Description: Program to open a file, call fork(), and write to
             the file from both the child and parent processes.
             The final contents of the file are then checked.
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    int fd;
    pid_t pid;

    /* Open the file */
    fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0666);

    if (fd == -1)
    {
        perror("Error opening file");
        return 1;
    }

    /* Create child process */
    pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        close(fd);
        return 1;
    }
    else if (pid == 0)
    {
        /* Child process */
        const char *child_msg = "This is written by the CHILD process.\n";

        if (write(fd, child_msg, 37) == -1)
        {
            perror("Child write failed");
            close(fd);
            return 1;
        }

        printf("Child process wrote to the file.\n");
    }
    else
    {
        /* Parent waits for child */
        wait(NULL);

        const char *parent_msg = "This is written by the PARENT process.\n";

        if (write(fd, parent_msg, 38) == -1)
        {
            perror("Parent write failed");
            close(fd);
            return 1;
        }

        printf("Parent process wrote to the file.\n");
    }

    close(fd);

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/22$ gcc 22.c -o 22.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/22$ ./22.out
Child process wrote to the file.
Parent process wrote to the file.
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/22$ cat output.txt
This is written by the CHILD process.This is written by the PARENT process.
*/