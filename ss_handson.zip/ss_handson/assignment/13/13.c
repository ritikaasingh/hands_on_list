/*
Project: 13.c
Author: Ritika Singh
Description: Program to wait for input from STDIN for 10 seconds
             using the select() system call.
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/select.h>

int main()
{
    fd_set readfds;
    struct timeval timeout;
    int result;
    char buffer[100];

    // Clear the file descriptor set
    FD_ZERO(&readfds);

    // Add STDIN (file descriptor 0) to the set
    FD_SET(STDIN_FILENO, &readfds);

    // Set timeout to 10 seconds
    timeout.tv_sec = 10;
    timeout.tv_usec = 0;

    printf("Waiting for input on STDIN for 10 seconds...\n");
    printf("Please enter some data: ");
    fflush(stdout);

    // Wait for STDIN to become ready
    result = select(STDIN_FILENO + 1, &readfds, NULL, NULL, &timeout);

    if (result == -1)
    {
        perror("select");
        return 1;
    }
    else if (result == 0)
    {
        printf("\nNo data was entered within 10 seconds.\n");
    }
    else
    {
        if (FD_ISSET(STDIN_FILENO, &readfds))
        {
            fgets(buffer, sizeof(buffer), stdin);
            printf("Data is available within 10 seconds: %s", buffer);
        }
    }

    return 0;
}

/*
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/13$ code 13.c
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/13$ gcc 13.c -o 13.out
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/13$ ./13.out
Waiting for input on STDIN for 10 seconds...
Please enter some data: hello
Data is available within 10 seconds: hello
ritika@Ritesh:/mnt/c/Users/ritik/Desktop/ss_handson/assignment/13$

*/